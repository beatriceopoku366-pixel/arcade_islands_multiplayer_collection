'use strict';
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const httpServer = http.createServer(app);
const io = new Server(httpServer, { pingInterval: 25000, pingTimeout: 20000 });
const PORT = Number(process.env.PORT) || 3000;
const MAX_PLAYERS = 8;
const MODES = new Set(['horror', 'racing', 'battle']);
const rooms = new Map();
app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));
app.get('/health', (_req, res) => res.json({ ok: true, rooms: rooms.size }));

const ITEM_LAYOUTS = {
  horror: Array.from({ length: 5 }, (_, i) => ({ id: `key-${i}`, x: Math.sin(i * 4) * (6 + (i % 2) * 5), z: Math.cos(i * 4) * (6 + (i % 2) * 5), collected: false }))
};
const COLORS = ['#ffcc66','#6ee7d8','#ff7a90','#9d8cff','#a8e063','#ff9f43','#74b9ff','#fd79a8'];
const makeCode = () => { let id; do { id = crypto.randomBytes(4).toString('hex').slice(0, 6).toUpperCase(); } while (rooms.has(id)); return id; };
function snapshot(room) {
  return { id: room.id, mode: room.mode, started: room.started, hostId: room.hostId,
    players: Object.values(room.players).map(p => ({ ...p })), items: room.items.map(i => ({ ...i })),
    arena: room.arena, winner: room.winner };
}
function publish(room) { io.to(room.id).emit('state', snapshot(room)); }
function note(socket, message) { socket.emit('notice', message); }
function createRoom(mode) {
  const room = { id: makeCode(), mode, players: {}, hostId: null, started: false,
    roundStart: 0, arena: 28, items: [], winner: null, lastAttack: new Map() };
  rooms.set(room.id, room); return room;
}
function leave(socket) {
  const roomId = socket.data.roomId;
  if (!roomId) return;
  const room = rooms.get(roomId);
  socket.leave(roomId); socket.data.roomId = null;
  if (!room) return;
  delete room.players[socket.id]; room.lastAttack.delete(socket.id);
  if (room.hostId === socket.id) room.hostId = Object.keys(room.players)[0] || null;
  if (!Object.keys(room.players).length) rooms.delete(roomId); else publish(room);
}
function join(socket, room, name) {
  if (socket.data.roomId) leave(socket);
  if (room.started) return note(socket, 'This round is already in progress. Try again when it finishes.');
  const ids = Object.keys(room.players);
  if (ids.length >= MAX_PLAYERS) return note(socket, 'This room is full (8 players maximum).');
  const p = { id: socket.id, name: String(name || 'Player').trim().slice(0, 18) || 'Player',
    color: COLORS[ids.length % COLORS.length], x: (Math.random() - .5) * 5,
    z: (Math.random() - .5) * 5, progress: 0, lane: 0, alive: true,
    finished: false, health: 100, danger: 0 };
  room.players[socket.id] = p;
  if (!room.hostId) room.hostId = socket.id;
  socket.data.roomId = room.id; socket.join(room.id);
  socket.emit('welcome', { id: socket.id, room: room.id, mode: room.mode });
  publish(room);
}
function finish(room, winner, message) {
  room.started = false; room.winner = winner || null;
  io.to(room.id).emit('notice', message); publish(room);
}

io.on('connection', socket => {
  socket.on('createRoom', payload => {
    const mode = payload && payload.mode;
    if (!MODES.has(mode)) return note(socket, 'Please select one of the available games first.');
    join(socket, createRoom(mode), payload.name);
  });
  socket.on('joinRoom', payload => {
    const code = String(payload && payload.code || '').trim().toUpperCase();
    const room = rooms.get(code);
    if (!room) return note(socket, 'Room code not found. Check the code and try again.');
    join(socket, room, payload.name);
  });
  socket.on('startRound', () => {
    const room = rooms.get(socket.data.roomId);
    if (!room) return note(socket, 'Create or join a room first.');
    if (room.hostId !== socket.id) return note(socket, 'Only the room host can start the round.');
    room.started = true; room.roundStart = Date.now(); room.arena = 28; room.winner = null;
    room.items = (ITEM_LAYOUTS[room.mode] || []).map(i => ({ ...i, collected: false }));
    room.lastAttack.clear();
    for (const p of Object.values(room.players)) {
      p.x = (Math.random() - .5) * 5; p.z = (Math.random() - .5) * 5;
      p.progress = 0; p.lane = 0; p.alive = true; p.finished = false; p.health = 100; p.danger = 0;
    }
    publish(room); io.to(room.id).emit('notice', 'Round started! Good luck.');
  });
  socket.on('move', data => {
    const room = rooms.get(socket.data.roomId);
    if (!room || !room.started || !data || typeof data !== 'object') return;
    const p = room.players[socket.id];
    if (!p || !p.alive || p.finished) return;
    if (room.mode === 'racing') {
      const progress = Number(data.progress), lane = Number(data.lane);
      if (Number.isFinite(progress)) p.progress = Math.max(p.progress, Math.min(100, Math.max(0, progress)));
      if (Number.isFinite(lane)) p.lane = Math.max(-2.2, Math.min(2.2, lane));
      if (p.progress >= 100) { p.finished = true; finish(room, p.id, `${p.name} wins the race!`); return; }
    } else {
      const x = Number(data.x), z = Number(data.z);
      if (Number.isFinite(x)) p.x = Math.max(-35, Math.min(35, x));
      if (Number.isFinite(z)) p.z = Math.max(-35, Math.min(35, z));
      if (room.mode === 'battle' && Math.hypot(p.x, p.z) > room.arena) p.alive = false;
    }
    publish(room);
  });
  socket.on('collectItem', itemId => {
    const room = rooms.get(socket.data.roomId);
    if (!room || !room.started || room.mode !== 'horror') return;
    const p = room.players[socket.id];
    const item = room.items.find(i => i.id === String(itemId) && !i.collected);
    if (!p || !p.alive || !item || Math.hypot(p.x - item.x, p.z - item.z) > 2.5) return;
    item.collected = true; publish(room);
    if (room.items.length && room.items.every(i => i.collected)) finish(room, null, 'All five keys found! You escaped the haunted forest!');
  });
  socket.on('attack', () => {
    const room = rooms.get(socket.data.roomId);
    if (!room || !room.started || room.mode !== 'battle') return;
    const attacker = room.players[socket.id];
    if (!attacker || !attacker.alive) return;
    const now = Date.now();
    if (now - (room.lastAttack.get(socket.id) || 0) < 650) return;
    room.lastAttack.set(socket.id, now);
    const target = Object.values(room.players).filter(p => p.id !== attacker.id && p.alive)
      .map(p => ({ p, d: Math.hypot(p.x - attacker.x, p.z - attacker.z) }))
      .filter(v => v.d < 3.2).sort((a, b) => a.d - b.d)[0]?.p;
    if (target) { target.health = Math.max(0, target.health - 35); if (!target.health) target.alive = false; }
    publish(room);
    const alive = Object.values(room.players).filter(p => p.alive);
    if (Object.keys(room.players).length > 1 && alive.length <= 1) finish(room, alive[0]?.id, alive.length ? `${alive[0].name} is the last player standing!` : 'Nobody survived the battle.');
  });
  socket.on('leaveRoom', () => leave(socket));
  socket.on('disconnect', () => leave(socket));
});

const interval = setInterval(() => {
  for (const room of rooms.values()) {
    if (!room.started) continue;
    if (room.mode === 'battle') {
      room.arena = Math.max(5, 28 - (Date.now() - room.roundStart) / 12000);
      for (const p of Object.values(room.players)) if (p.alive && Math.hypot(p.x, p.z) > room.arena) p.alive = false;
      const alive = Object.values(room.players).filter(p => p.alive);
      if (Object.keys(room.players).length > 1 && alive.length <= 1) finish(room, alive[0]?.id, alive.length ? `${alive[0].name} is the last player standing!` : 'Nobody survived the storm.');
      else publish(room);
    } else if (room.mode === 'horror') {
      const elapsed = (Date.now() - room.roundStart) / 1000;
      for (const p of Object.values(room.players)) if (p.alive) {
        p.danger = Math.max(0, Math.min(100, (Math.hypot(p.x, p.z) > 13 ? elapsed * 2.8 : elapsed * .7) - 8));
        if (p.danger >= 100) p.alive = false;
      }
      if (Object.values(room.players).every(p => !p.alive)) finish(room, null, 'The monster caught everyone. Start another round to try again.');
      else publish(room);
    }
  }
}, 500);
httpServer.listen(PORT, () => console.log(`Arcade Islands running at http://localhost:${PORT}`));
process.on('SIGINT', () => { clearInterval(interval); httpServer.close(() => process.exit(0)); });
