# Arcade Islands Multiplayer Collection — repaired build

This ZIP contains the three game modes in the uploaded project: Survival Horror, Island Racing and Battle Royale. The previous upload did not contain an Adventure Island game, so this repair does not pretend that one exists.

## Run on Windows
1. Extract this ZIP into a NEW folder. Do not overwrite the original project.
2. Open the extracted folder in VS Code or PowerShell.
3. Run `npm install` once.
4. Run `npm start`.
5. Open `http://localhost:3000`.
6. Create a room, then click **Start round** as the room host.

## Controls
- Horror and Battle Royale: W/A/S/D or arrow keys to move.
- Racing: hold W / Up to accelerate; S / Down to brake; A/D or Left/Right to steer.
- Battle Royale: press Space to attack a nearby opponent.

## Multiplayer
The room creator is host. Share the six-character room code. Other players must connect to the same server address. Rooms support up to eight players.

## Technical notes
- Static files are served from this folder using an absolute path, so the server can be launched from a different working directory.
- The local avatar is drawn as soon as the 3D scene is created, then reconciled with the server state. This avoids waiting for a later state packet before displaying the player.
- The player model uses basic Three.js primitives rather than CapsuleGeometry.
- The game still loads Three.js from jsDelivr, so internet access is required for the 3D renderer.
- This is a repaired prototype, not a production-hardened public game server. A live multi-browser playtest is still required on the target computer/network.
