import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';

const socket = io();
const $ = id => document.getElementById(id);
const MODE_NAMES = { horror: 'SURVIVAL HORROR', racing: 'ISLAND RACING', battle: 'BATTLE ROYALE' };
const HELP = {
  horror: 'Find all five glowing keys. Move with W/A/S/D or the arrow keys. Stay alert and avoid the monster.',
  racing: 'Hold W / ↑ to accelerate, S / ↓ to brake, and use A / ← or D / → to steer. Reach 100% first.',
  battle: 'Move with W/A/S/D or the arrow keys. Press SPACE to attack nearby rivals. Stay inside the safe zone.'
};
let chosenMode = 'horror', myId = null, roomCode = null, mode = null, state = null;
let scene = null, camera = null, renderer = null, clock = null, animationId = 0;
let playerMeshes = new Map(), itemMeshes = new Map(), keys = Object.create(null);
let localX = 0, localZ = 0, progress = 0, lane = 0, lastMoveAt = 0, lastAttackAt = 0;
let roundStarted = false, pendingItems = new Set(), worldError = false;

function setStatus(message) { $('status').textContent = message; }
window.choose = modeName => {
  if (!MODE_NAMES[modeName]) return;
  chosenMode = modeName;
  document.querySelectorAll('.game-card').forEach(card => card.style.opacity = '.72');
  const card = document.querySelector(`.${modeName}`); if (card) card.style.opacity = '1';
  setStatus(`${MODE_NAMES[modeName]} selected. Create a room or join a friend's code.`);
};
$('createBtn').addEventListener('click', () => socket.emit('createRoom', { mode: chosenMode, name: $('nickname').value || 'Player' }));
$('joinBtn').addEventListener('click', () => socket.emit('joinRoom', { code: $('roomCode').value, name: $('nickname').value || 'Player' }));
$('startBtn').addEventListener('click', () => socket.emit('startRound'));
$('leaveBtn').addEventListener('click', () => {
  socket.emit('leaveRoom'); $('gamePanel').classList.add('hidden'); $('lobby').classList.remove('hidden');
  disposeWorld(); state = null; mode = null; myId = null; keys = Object.create(null);
});
$('copyBtn').addEventListener('click', async () => {
  try { await navigator.clipboard.writeText(roomCode); $('copyBtn').textContent = 'Copied!'; }
  catch { setStatus(`Your invite code is ${roomCode}. Copy it manually.`); }
});
socket.on('connect', () => setStatus('Connected to the game server. Choose a game to begin.'));
socket.on('connect_error', () => setStatus('Could not connect to the game server. Check that npm start is running, then refresh.'));
socket.on('notice', message => { setStatus(message); if (message.toLowerCase().includes('round started')) $('objective').textContent = message; });
socket.on('welcome', data => {
  myId = data.id; roomCode = data.room; mode = data.mode;
  $('lobby').classList.add('hidden'); $('gamePanel').classList.remove('hidden');
  $('roomTitle').textContent = `Room ${roomCode}`; $('modeLabel').textContent = MODE_NAMES[mode] || mode;
  $('controlsText').textContent = HELP[mode] || '';
  $('objective').textContent = 'Waiting for the room state…';
  localX = 0; localZ = 0; progress = 0; lane = 0; state = null; roundStarted = false; pendingItems.clear();
  try { buildWorld(); } catch (error) { showWorldError(error); }
});
socket.on('state', incoming => {
  if (!incoming || !incoming.players) return;
  const wasStarted = roundStarted;
  state = incoming; roundStarted = !!incoming.started;
  if (!wasStarted && roundStarted) { progress = 0; lane = 0; pendingItems.clear(); }
  const me = state.players.find(player => player.id === myId);
  if (me) {
    // Use authoritative position on round start; otherwise keep local prediction smooth.
    if (!wasStarted && roundStarted) { localX = me.x; localZ = me.z; }
    if (mode === 'racing') { progress = Math.max(progress, me.progress || 0); lane = me.lane || 0; }
  }
  if (!scene && !worldError) { try { buildWorld(); } catch (error) { showWorldError(error); } }
  updatePlayers(); updateStartButton(); syncMeshes(); updateObjective();
});
function updateStartButton() {
  if (!state) return;
  const host = state.hostId === myId;
  $('startBtn').disabled = !host || state.started;
  $('startBtn').textContent = state.started ? 'Round in progress' : host ? 'Start round' : 'Waiting for host';
  $('startBtn').title = host ? 'Start a new round' : 'Only the room host can start a round';
}
function updatePlayers() {
  $('playerCount').textContent = `${state.players.length}/8`;
  $('players').replaceChildren();
  [...state.players].sort((a, b) => b.progress - a.progress).forEach(player => {
    const li = document.createElement('li'); if (!player.alive) li.className = 'dead';
    const name = document.createElement('span'); name.textContent = `${player.id === myId ? '★ ' : ''}${player.name}`;
    const score = document.createElement('span');
    score.textContent = mode === 'racing' ? `${Math.floor(player.progress)}%` : !player.alive ? 'OUT' : mode === 'battle' ? `${player.health} HP` : '';
    li.append(name, score); $('players').append(li);
  });
}
function updateObjective() {
  if (!state) return;
  if (mode === 'horror') {
    const remaining = state.items.filter(item => !item.collected).length;
    const me = state.players.find(player => player.id === myId);
    $('objective').textContent = `Keys remaining: ${remaining} • Danger: ${Math.round(me?.danger || 0)}%`;
  } else if (mode === 'racing') $('objective').textContent = 'Reach 100% progress. Use A/D to steer around the track.';
  else $('objective').textContent = `Safe-zone radius: ${Number(state.arena).toFixed(1)} • SPACE attacks nearby rivals.`;
}
function makePlayerMesh(player) {
  const group = new THREE.Group();
  const suit = new THREE.MeshStandardMaterial({ color: player.color || '#65aaff', roughness: .7 });
  const skin = new THREE.MeshStandardMaterial({ color: 0xffd2a8, roughness: .8 });
  const torso = new THREE.Mesh(new THREE.CylinderGeometry(.34, .42, .95, 12), suit);
  torso.position.y = .82; torso.castShadow = true; group.add(torso);
  const head = new THREE.Mesh(new THREE.SphereGeometry(.27, 16, 12), skin);
  head.position.y = 1.48; head.castShadow = true; group.add(head);
  const leftLeg = new THREE.Mesh(new THREE.CylinderGeometry(.11, .13, .48, 8), suit);
  leftLeg.position.set(-.16, .23, 0); group.add(leftLeg);
  const rightLeg = leftLeg.clone(); rightLeg.position.x = .16; group.add(rightLeg);
  // Bright ring under every avatar makes it easy to see on the island floor.
  const marker = new THREE.Mesh(new THREE.RingGeometry(.48, .62, 24), new THREE.MeshBasicMaterial({ color: player.color || '#65aaff', side: THREE.DoubleSide }));
  marker.rotation.x = -Math.PI / 2; marker.position.y = .035; group.add(marker);
  return group;
}
function buildWorld() {
  disposeWorld(); worldError = false;
  const host = $('viewport'); host.replaceChildren();
  const width = Math.max(320, host.clientWidth || 800), height = Math.max(260, host.clientHeight || 440);
  scene = new THREE.Scene();
  scene.background = new THREE.Color(mode === 'horror' ? 0x10152a : mode === 'racing' ? 0x91c9ff : 0x9acbff);
  scene.fog = new THREE.Fog(scene.background, 42, 105);
  camera = new THREE.PerspectiveCamera(58, width / height, .1, 200);
  camera.position.set(0, 14, 20);
  renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
  renderer.setSize(width, height); renderer.shadowMap.enabled = false;
  host.appendChild(renderer.domElement);
  clock = new THREE.Clock();
  scene.add(new THREE.HemisphereLight(0xe4f2ff, 0x26351f, 1.8));
  const sun = new THREE.DirectionalLight(0xffffff, 2.0); sun.position.set(8, 20, 8); scene.add(sun);
  const ground = new THREE.Mesh(new THREE.CircleGeometry(44, 64), new THREE.MeshStandardMaterial({ color: mode === 'horror' ? 0x24382d : mode === 'racing' ? 0x3b995c : 0x3a8f61, roughness: 1 }));
  ground.rotation.x = -Math.PI / 2; ground.position.y = -.06; scene.add(ground);
  if (mode === 'racing') {
    const road = new THREE.Mesh(new THREE.RingGeometry(8.5, 13.5, 80), new THREE.MeshStandardMaterial({ color: 0x343d4c, side: THREE.DoubleSide }));
    road.rotation.x = -Math.PI / 2; road.position.y = .02; scene.add(road);
    for (let i = 0; i < 20; i++) { const a = i * Math.PI / 10; const gate = new THREE.Mesh(new THREE.BoxGeometry(.7, .22, .7), new THREE.MeshStandardMaterial({ color: 0x44d7ff, emissive: 0x116688 })); gate.position.set(Math.sin(a) * 11, .2, Math.cos(a) * 11); scene.add(gate); }
  } else {
    for (let i = 0; i < 24; i++) {
      const tree = new THREE.Group();
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(.18, .25, 1.3, 7), new THREE.MeshStandardMaterial({ color: 0x755036 })); trunk.position.y = .65; tree.add(trunk);
      const crown = new THREE.Mesh(new THREE.ConeGeometry(.9, 2, 7), new THREE.MeshStandardMaterial({ color: mode === 'horror' ? 0x183e35 : 0x24854b })); crown.position.y = 1.9; tree.add(crown);
      const angle = i * 2.4; tree.position.set(Math.sin(angle) * (16 + i % 4 * 3), 0, Math.cos(angle) * (16 + i % 4 * 3)); scene.add(tree);
    }
    if (mode === 'horror') {
      const monster = new THREE.Mesh(new THREE.SphereGeometry(.8, 16, 12), new THREE.MeshStandardMaterial({ color: 0xb34cff, emissive: 0x481070 }));
      monster.position.set(0, .9, 0); scene.add(monster); monster.userData.isMonster = true;
    }
  }
  if (mode === 'battle') {
    const safe = new THREE.Mesh(new THREE.CircleGeometry(28, 64), new THREE.MeshBasicMaterial({ color: 0x56d7a4, transparent: true, opacity: .1, side: THREE.DoubleSide }));
    safe.rotation.x = -Math.PI / 2; safe.position.y = .015; scene.add(safe);
  }
  // Spawn a visible local avatar immediately; it is replaced with authoritative player data on state.
  const provisional = makePlayerMesh({ id: myId, color: '#ffe16b' }); provisional.position.set(localX, 0, localZ); scene.add(provisional); playerMeshes.set(myId, provisional);
  if (state) syncMeshes();
  animate();
}
function disposeWorld() {
  if (animationId) cancelAnimationFrame(animationId); animationId = 0;
  if (renderer) { renderer.dispose(); if (renderer.domElement.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement); }
  renderer = null; scene = null; camera = null; clock = null; playerMeshes.clear(); itemMeshes.clear();
}
function syncMeshes() {
  if (!scene || !state) return;
  for (const player of state.players) {
    let mesh = playerMeshes.get(player.id);
    if (!mesh) { mesh = makePlayerMesh(player); scene.add(mesh); playerMeshes.set(player.id, mesh); }
    mesh.visible = player.alive;
    if (player.id !== myId) {
      if (mode === 'racing') { const angle = player.progress / 100 * Math.PI * 2; mesh.position.set(Math.sin(angle) * (11 + (player.lane || 0)), 0, Math.cos(angle) * (11 + (player.lane || 0))); }
      else mesh.position.set(player.x, 0, player.z);
    }
  }
  for (const [id, mesh] of playerMeshes) if (!state.players.some(p => p.id === id) && id !== myId) { scene.remove(mesh); playerMeshes.delete(id); }
  for (const item of state.items || []) {
    let mesh = itemMeshes.get(item.id);
    if (!mesh) { mesh = new THREE.Mesh(new THREE.OctahedronGeometry(.55), new THREE.MeshStandardMaterial({ color: 0xffd44d, emissive: 0x996600, emissiveIntensity: 1.1 })); mesh.position.set(item.x, .8, item.z); scene.add(mesh); itemMeshes.set(item.id, mesh); }
    mesh.visible = !item.collected;
    if (item.collected) pendingItems.delete(item.id);
  }
  if (mode === 'battle') {
    const existing = scene.getObjectByName('storm-ring');
    if (existing) scene.remove(existing);
    const ring = new THREE.Mesh(new THREE.RingGeometry(Math.max(4, state.arena - .35), state.arena, 64), new THREE.MeshBasicMaterial({ color: 0xff576d, side: THREE.DoubleSide }));
    ring.name = 'storm-ring'; ring.rotation.x = -Math.PI / 2; ring.position.y = .08; scene.add(ring);
  }
}
function showWorldError(error) {
  worldError = true; disposeWorld();
  const host = $('viewport'); host.innerHTML = '<div class="loading">The 3D scene could not start. Check that your browser supports WebGL and that the Three.js CDN is reachable, then refresh.</div>';
  console.error('Arcade Islands 3D initialisation failed:', error);
}
function animate() {
  if (!renderer || !scene) return;
  const tick = () => {
    if (!renderer || !scene) return;
    animationId = requestAnimationFrame(tick);
    const dt = Math.min(clock.getDelta(), .05);
    const me = state?.players.find(player => player.id === myId);
    if (me && me.alive && roundStarted) {
      if (mode === 'racing') {
        const accel = (keys.w || keys.ArrowUp) ? 1 : (keys.s || keys.ArrowDown) ? -.45 : 0;
        progress = Math.max(0, Math.min(100, progress + accel * dt * 12));
        const steer = (keys.a || keys.ArrowLeft) ? -1 : (keys.d || keys.ArrowRight) ? 1 : 0;
        lane = Math.max(-2.2, Math.min(2.2, lane + steer * dt * 3));
        const angle = progress / 100 * Math.PI * 2;
        const mine = playerMeshes.get(myId); if (mine) mine.position.set(Math.sin(angle) * (11 + lane), 0, Math.cos(angle) * (11 + lane));
        if (performance.now() - lastMoveAt > 90) { socket.emit('move', { progress, lane }); lastMoveAt = performance.now(); }
      } else {
        const dx = ((keys.d || keys.ArrowRight) ? 1 : 0) - ((keys.a || keys.ArrowLeft) ? 1 : 0);
        const dz = ((keys.s || keys.ArrowDown) ? 1 : 0) - ((keys.w || keys.ArrowUp) ? 1 : 0);
        const length = Math.hypot(dx, dz) || 1; const speed = mode === 'battle' ? 8 : 6;
        if (dx || dz) { localX = THREE.MathUtils.clamp(localX + dx / length * speed * dt, -35, 35); localZ = THREE.MathUtils.clamp(localZ + dz / length * speed * dt, -35, 35); }
        const mine = playerMeshes.get(myId); if (mine) mine.position.set(localX, 0, localZ);
        if (mode === 'horror') for (const item of state.items) {
          if (!item.collected && !pendingItems.has(item.id) && Math.hypot(localX - item.x, localZ - item.z) < 1.5) { pendingItems.add(item.id); socket.emit('collectItem', item.id); }
        }
        if (performance.now() - lastMoveAt > 90) { socket.emit('move', { x: localX, z: localZ }); lastMoveAt = performance.now(); }
        if (mode === 'battle' && keys.Space && performance.now() - lastAttackAt > 700) { socket.emit('attack'); lastAttackAt = performance.now(); }
      }
    }
    if (mode === 'horror' && scene && me) {
      const monster = scene.children.find(child => child.userData.isMonster);
      if (monster) { monster.position.x += (me.x - monster.position.x) * dt * .08; monster.position.z += (me.z - monster.position.z) * dt * .08; }
    }
    const mine = playerMeshes.get(myId);
    if (mine && camera) { const target = new THREE.Vector3(mine.position.x, mode === 'racing' ? 12 : 12.5, mine.position.z + (mode === 'racing' ? 17 : 18)); camera.position.lerp(target, .08); camera.lookAt(mine.position.x, .5, mine.position.z); }
    renderer.render(scene, camera);
  };
  tick();
}
const CODE_MAP = { KeyW: 'w', KeyA: 'a', KeyS: 's', KeyD: 'd', ArrowUp: 'ArrowUp', ArrowDown: 'ArrowDown', ArrowLeft: 'ArrowLeft', ArrowRight: 'ArrowRight', Space: 'Space' };
function isTyping(target) { return target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable); }
document.addEventListener('keydown', event => {
  const key = CODE_MAP[event.code]; if (!key || $('gamePanel').classList.contains('hidden') || isTyping(event.target)) return;
  event.preventDefault(); keys[key] = true;
}, true);
document.addEventListener('keyup', event => { const key = CODE_MAP[event.code]; if (key) keys[key] = false; }, true);
window.addEventListener('blur', () => { keys = Object.create(null); });
document.addEventListener('visibilitychange', () => { if (document.hidden) keys = Object.create(null); });
window.addEventListener('resize', () => {
  if (!renderer || !camera) return;
  const host = $('viewport'), width = Math.max(1, host.clientWidth), height = Math.max(1, host.clientHeight);
  camera.aspect = width / height; camera.updateProjectionMatrix(); renderer.setSize(width, height);
});
